<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Aprendiendo PHP</title>
    <link href="https://fonts.googleapis.com/css?family=Proza+Libre" rel="stylesheet">

    <link rel="stylesheet" href="css/estilos.css" media="screen" title="no title">
  </head>
  <body>

    <div class="contenedor">
      <h1>Aprendiendo PHP</h1>

        <div class="contenido">
            <?php 
                $nombre =  "Estefany";
                $apellido = "Vásquez";
                
                echo $nombre . " " . $apellido;
                
                $edad = 22;
                echo "<hr>";

                echo $nombre . " edad: " . $edad;

                echo "<hr>";

                $municipio = "San salvador";

                $pais = "El salvador";

                $favorito = "30";

                echo "Hola, mi nombre es ".$nombre . " " . $apellido.", vivo en el municipio de ".$municipio.", en el país ".$pais.", tengo ".$edad." años; y mi numero favorito es el ".$favorito.". ";
 
                
             ?>
              
        </div>
    </div>




  </body>
</html>
