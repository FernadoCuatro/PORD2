<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Aprendiendo PHP</title>
    <link href="https://fonts.googleapis.com/css?family=Proza+Libre" rel="stylesheet">

    <link rel="stylesheet" href="css/estilos.css" media="screen" title="no title">
  </head>
  <body>

    <div class="contenedor">
      <h1>Aprendiendo PHP</h1>

        <div class="contenido">
            <?php
                  $hola = "Hola Mundo";
                  $numero =  20;
                  
                  $hola_mundo = "Hola Mundo";
                  
                  echo $hola_mundo;
                  
                  $saludos = "<h1>Hola</h1>";
                  echo $saludos;

                  $bool1 = true;

                  $bool2 = false;


                  $entero = 42;
                  echo $entero;
                  $hexadecimal = 0x22;
                  echo $hexadecimal;

                  $float = 0.04;
                  echo $float;
                  $double = 3.3333;
                  echo $double;
            
            ?>
        </div>
    </div>




  </body>
</html>
